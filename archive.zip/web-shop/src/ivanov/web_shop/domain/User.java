/**
 * 
 */
package ivanov.web_shop.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.PostPersist;
import javax.persistence.PostRemove;
import javax.persistence.PostUpdate;
import javax.persistence.Table;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
/**
 * @author papa
 *
 */
@Entity
@Table(name="users")
public class User {
	public static final byte USER = 0; //пользователь
	public static final byte ADMIN = 1; //администратор
	@Id
	@GeneratedValue
	@Column(name="id")
	private int id;
	@Column(name="name", nullable=false)
	private String name;
	@Column(name="password", nullable=false)
	private String password;
	@Column(name="role", nullable=false)
	private byte role; 
	final static Logger logger = LoggerFactory.getLogger(User.class);
	/**
	 * 
	 */
	public User() {
	}
	
	public User(String aName, String aPassword) {
		name = aName;
		password = aPassword;
		role = 0;
	}
	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}
	/**
	 * @param password the password to set
	 */
	public void setPassword(String password) {
		this.password = password;
	}
	/**
	 * @return the role
	 */
	public byte getRole() {
		return role;
	}
	/**
	 * @param role the role to set
	 */
	public void setRole(byte role) {
		this.role = role;
	}
	@Override
	public int hashCode() {
		return id;
	}
	@Override
	public boolean equals(Object o) {
		if( this == o)
			return true;
		
		if(!(o instanceof User))
			return false;
		
		return this.id == ((User) o).id;
	}

	public boolean isAdmin() {
		return this.role == User.ADMIN;
	}
	
	@PostPersist
	void postPersist() {
		logger.info(String.format("Добавлен пользователь %d", id));
	}
	
	@PostUpdate
	void postUpdate() {
		logger.info(String.format("Изменён пользователь %d", id));
	}
	
	@PostRemove
	void postRemove() {
		logger.info(String.format("Удалён пользователь %d", id));
	}
}
