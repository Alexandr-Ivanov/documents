/**
 * 
 */
package ivanov.web_shop.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.PostPersist;
import javax.persistence.PostRemove;
import javax.persistence.PostUpdate;
import javax.persistence.Table;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author papa
 *
 */
@Entity
@Table(name="wares")
public class Product {
	@Id
	@GeneratedValue
	@Column(name="id")
	private int id;
	@Column(name="name", nullable=false)
	private String name;
	@Column(name="description")
	private String description;
	@Column(name="price", nullable=false)
	private double price;
	@Column(name="value", nullable=false)
	private double value;
	final static Logger logger = LoggerFactory.getLogger(Product.class);
	/**
	 * 
	 */
	public Product() {
	}
	
	public Product(String aName, String aDescription, double aPrice, double aValue) {
		name = aName;
		description = aDescription;
		price = aPrice;
		value = aValue;
	}
	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}
	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}
	/**
	 * @return the price
	 */
	public double getPrice() {
		return price;
	}
	/**
	 * @param price the price to set
	 */
	public void setPrice(double price) {
		this.price = price;
	}
	/**
	 * @return the value
	 */
	public double getValue() {
		return value;
	}
	/**
	 * @param value the value to set
	 */
	public void setValue(double value) {
		this.value = value;
	}
	@Override
	public int hashCode() {
		return id;
	}
	@Override
	public boolean equals(Object o) {
		if( this == o)
			return true;
		
		if(!(o instanceof Product))
			return false;
		
		return this.id == ((Product) o).id;
	}
	
	public void subtract(double aValue) {
		value = value - aValue;
	}
	
	@PostPersist
	void postPersist() {
		logger.info(String.format("Добавлен товар %d", id));
	}
	
	@PostUpdate
	void postUpdate() {
		logger.info(String.format("Изменён товар %d", id));
	}
	
	@PostRemove
	void postRemove() {
		logger.info(String.format("Удалён товар %d", id));
	}
}
