/**
 * 
 */
package ivanov.web_shop.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.PostPersist;
import javax.persistence.PostRemove;
import javax.persistence.PostUpdate;
import javax.persistence.Table;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author papa
 *
 */
@Entity
@Table(name="purchases")
public class Purchase {
	@Id
	@GeneratedValue
	@Column(name="id")
	private int id;
	@Column(name="user_id", nullable=false)
	private int userId;
	@Column(name="ware_id", nullable=false)
	private int productId;
	@Column(name="price", nullable=false)
	private double price;
	@Column(name="value", nullable=false)
	private double value;
	final static Logger logger = LoggerFactory.getLogger(Purchase.class);
	/**
	 * 
	 */
	public Purchase() {
	}
	
	public Purchase(int anUser, int aProduct, double aPrice, double aValue) {
		userId = anUser;
		productId = aProduct;
		price = aPrice;
		value = aValue;
	}
	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}
	/**
	 * @return the user
	 */
	public int getUserId() {
		return userId;
	}
	/**
	 * @param user the user to set
	 */
	public void setUserId(int userId) {
		this.userId = userId;
	}
	/**
	 * @return the product
	 */
	public int getProductId() {
		return productId;
	}
	/**
	 * @param product the product to set
	 */
	public void setProductId(int productId) {
		this.productId = productId;
	}
	/**
	 * @return the price
	 */
	public double getPrice() {
		return price;
	}
	/**
	 * @param price the price to set
	 */
	public void setPrice(double price) {
		this.price = price;
	}
	/**
	 * @return the value
	 */
	public double getValue() {
		return value;
	}
	/**
	 * @param value the value to set
	 */
	public void setValue(double value) {
		this.value = value;
	}

	@PostPersist
	void postPersist() {
		logger.info(String.format("Добавлена покупка %d", id));
	}
	
	@PostUpdate
	void postUpdate() {
		logger.info(String.format("Изменена покупка %d", id));
	}
	
	@PostRemove
	void postRemove() {
		logger.info(String.format("Удалена покупка %d", id));
	}
}
