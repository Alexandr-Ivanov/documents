/**
 * 
 */
package ivanov.web_shop;

import javax.persistence.EntityManagerFactory;

/**
 * @author papa
 *
 */
public final class Globals {
	public static EntityManagerFactory emf;

}
