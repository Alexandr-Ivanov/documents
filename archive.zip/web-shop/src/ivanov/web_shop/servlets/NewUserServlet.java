/**
 * 
 */
package ivanov.web_shop.servlets;

import ivanov.web_shop.controller.Users;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Map;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @author papa
 *
 */
public class NewUserServlet extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 134382936320985236L;
	@Override
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
		request.setCharacterEncoding("UTF-8");
		final StringBuilder buffer = new StringBuilder();
		@SuppressWarnings("unchecked")
		final Map<String, String[]> params = request.getParameterMap();
		
		for (String name : params.keySet()) {
			buffer.append(name + "=");
			String[] values = params.get(name);
			
			for (String value : values) {
				buffer.append(value + ";");
			}
			
			buffer.append("// ");
		}
		
		final String userName = request.getParameter("user");
		
		if ((null == userName) || (userName.length() == 0)) {
			formErrorResponse(response, "Укажите имя пользователя.");
			log("Создать пользователя не удалось" + "; " + buffer);
			return;
		}
		
		final String password1 = request.getParameter("password1");
		final String password2 = request.getParameter("password2");
		
		if ((null == password1) || (password1.length() == 0) || !(password1.equals(password2))) {
			formErrorResponse(response, "Укажите два раза один и тот же пароль.");
			log("Создать пользователя не удалось" + "; " + buffer);
			return;
		}
	
		if (Users.addUser(userName, password1)) {
			formResponse(response, userName);
			log("Создан новый пользователь" + "; " + buffer);
		}
		else {
			formErrorResponse(response, "Создать пользователя " + userName + " не удалось.");
			log("Создать пользователя не удалось" + "; " + buffer);
		}
	}
	private void formErrorResponse(HttpServletResponse response, String message) throws IOException {
		response.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=utf-8");
		final PrintWriter writer = response.getWriter();
		writer.print("<html><head><title>Новый пользователь</title></head><body>");
		writer.print("<h1>" + message + "</h1>");
		writer.println("</body></html>");
	}
	private void formResponse(HttpServletResponse response, String userName) throws IOException {
		response.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=utf-8");
		final PrintWriter writer = response.getWriter();
		writer.print("<html><head><title>Новый пользователь</title></head><body>");
		writer.print("<h1>Зарегистрирован пользователь " + userName + ".</h1>");
		writer.println("</body></html>");
	}

}
