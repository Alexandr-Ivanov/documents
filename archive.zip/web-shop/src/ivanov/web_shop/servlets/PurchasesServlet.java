/**
 * 
 */
package ivanov.web_shop.servlets;

import ivanov.web_shop.controller.Session;
import ivanov.web_shop.controller.Sessions;
import ivanov.web_shop.controller.Shop;
import ivanov.web_shop.controller.Users;
import ivanov.web_shop.domain.Product;
import ivanov.web_shop.domain.Purchase;
import ivanov.web_shop.domain.User;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Collection;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @author papa
 *
 */
public class PurchasesServlet extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1131750343346982263L;
	
	@Override
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
		final String context = request.getContextPath();
		boolean success = false;
		long sessionId = 0;
		final Cookie[] cookies = request.getCookies();
		
		if (null == cookies) {
			response.sendRedirect(context);
			log("Запрос списка покупок не выполнен; сессия не задана");
			return;
		}
		
		for (Cookie cookie : cookies) {
			
			if (cookie.getName().equals("WebShopSession")) {
				try {
					sessionId = Long.parseLong(cookie.getValue());
				} catch (NumberFormatException e) {
					response.sendRedirect(context);
					break;
				}
				
				final Session session = Sessions.getSession(sessionId);
				
				if (null == session) {
					response.sendRedirect(context);
					break;
				}
				
				if (!session.isAdmin()) {
					response.sendRedirect(context);
					break;
				}
					
				success = true;
				formResponse(response);
			}
		}
		
		log("Запрос списка покупок " + (success ? "выполнен" : "не выполнен") + "; сессия " + sessionId);
	}
	private void formResponse(HttpServletResponse response) throws IOException {
		response.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=utf-8");
		final PrintWriter writer = response.getWriter();
		writer.print("<html><head><title>Покупки</title></head><body><h1>Покупки</h1><table border = 1>");
		writer.print("<th>пользователь</th><th>наименование</th><th>цена</th><th>количество</th>");
		final Collection<Purchase> purchases = Shop.getPurchases();
		
		for (Purchase purchase : purchases) {
			User user = Users.getUser(purchase.getUserId());
			Product product = Shop.getProduct(purchase.getProductId());
			writer.print("<tr><td>" + (null == user ? "неизвестный" : user.getName()) + "</td><td>" + 
					(null == product ? "?" : product.getName()) + "</td><td>" + purchase.getPrice() + "</td><td>" + 
					purchase.getValue() + "</td></tr>");
		}
		
		writer.println("</table>");
		writer.println("</body></html>");
	}

}
