/**
 * 
 */
package ivanov.web_shop.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Collection;

import ivanov.web_shop.controller.Session;
import ivanov.web_shop.controller.Sessions;
import ivanov.web_shop.controller.Users;
import ivanov.web_shop.domain.User;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @author papa
 *
 */
public class UsersServlet extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5311872001677483201L;
	@Override
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
		final String context = request.getContextPath();
		boolean success = false;
		long sessionId = 0;
		final Cookie[] cookies = request.getCookies();
		
		if (null == cookies) {
			response.sendRedirect(context);
			log("Запрос списка пользователей не выполнен; сессия не задана");
			return;
		}
		
		for (Cookie cookie : cookies) {
			
			if (cookie.getName().equals("WebShopSession")) {
				
				try {
					sessionId = Long.parseLong(cookie.getValue());
				} catch (NumberFormatException e) {
					response.sendRedirect(context);
					break;
				}
				final Session session = Sessions.getSession(sessionId);
				
				if (null == session) {
					response.sendRedirect(context);
					break;
				}
					
				if (!session.isAdmin()) {
					response.sendRedirect(context);
					break;
				}
				
				success = true;
				formResponse(response);
			}
		}
		
		log("Запрос списка пользователей " + (success ? "выполнен" : "не выполнен") + "; сессия " + sessionId);
	}
	
	private void formResponse(HttpServletResponse response) throws IOException {
		response.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=utf-8");
		final PrintWriter writer = response.getWriter();
		 writer.print("<html><head><title>Пользователи</title></head><body><h1>Пользователи</h1><table border = 1>");
		 writer.print("<tr><th>номер</th><th>имя</th><th>роль</th></tr>");
		final Collection<User> users = Users.getUsers();
		
		for (User user : users) {
			writer.print("<tr><td>" + user.getId() + "</td><td>" + user.getName() + "</td><td>" + (user.isAdmin() ? "администратор" : "пользователь") + 
					"</td></tr>");
		}
		
		writer.println("</table>");
		writer.println("</body></html>");
	}
}
