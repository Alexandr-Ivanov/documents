/**
 * 
 */
package ivanov.web_shop.servlets;

import ivanov.web_shop.controller.Session;
import ivanov.web_shop.controller.Sessions;
import ivanov.web_shop.controller.Shop;
import ivanov.web_shop.domain.Product;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Collection;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @author papa
 *
 */
public class StockServlet extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2811640991286002745L;

	@Override
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
		final String context = request.getContextPath();
		boolean success = false;
		long sessionId = 0;
		final Cookie[] cookies = request.getCookies();
		
		if (null == cookies) {
			response.sendRedirect(context);
			log("Запрос списка товаров не выполнен; сессия не задана");
			return;
		}
		
		for (Cookie cookie : cookies) {
			
			if (cookie.getName().equals("WebShopSession")) {
				try {
					sessionId = Long.parseLong(cookie.getValue());
				} catch (NumberFormatException e) {
					response.sendRedirect(context);
					break;
				}
				final Session session = Sessions.getSession(sessionId);
				
				if (null == session) {
					response.sendRedirect(context);
					break;
				}
					
				success = true;
				formResponse(response, session.isAdmin());
			}
		}
		
		log("Запрос списка товаров " + (success ? "выполнен" : "не выполнен") + "; сессия " + sessionId);
	}

	private void formResponse(HttpServletResponse response, boolean admin) throws IOException {
		response.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=utf-8");
		final PrintWriter writer = response.getWriter();
		writer.print("<html><head><title>Товары</title></head><body><h1>Товары в наличии</h1><table border = 1>");
		writer.print("<th>каталожный номер</th><th>наименование</th><th>цена</th><th>количество</th><th>описание</th>");
		final Collection<Product> products = Shop.getProducts();
		
		for (Product product : products) {
			writer.print("<tr><td>" + product.getId() + "</td><td>" + product.getName() + "</td><td>" + product.getPrice() + "</td><td>" + product.getValue() + "</td><td>" +
					product.getDescription() + "</td></tr>");
		}
		
		writer.println("</table>");
		writer.println("</body></html>");
	}
}