/**
 * 
 */
package ivanov.web_shop.servlets;

import ivanov.web_shop.controller.Session;
import ivanov.web_shop.controller.Sessions;
import ivanov.web_shop.controller.Shop;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Map;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @author papa
 *
 */
public class DeleteProductServlet extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2572535189946137252L;
	
	@Override
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws IOException {
		final String context = request.getContextPath();
		boolean success = false;
		long sessionId = 0;
		final Cookie[] cookies = request.getCookies();

		if (null == cookies) {
			response.sendRedirect(context);
			log("Удаление товара не выполнено; сессия не задана");
			return;
		}
		
		for (Cookie cookie : cookies) {

			if (cookie.getName().equals("WebShopSession")) {
				
				try {
					sessionId = Long.parseLong(cookie.getValue());
				} catch (NumberFormatException e) {
					response.sendRedirect(context);
					break;
				}
				
				final Session session = Sessions.getSession(sessionId);

				if (null == session) {
					response.sendRedirect(context);
					break;
				}

				if (!session.isAdmin()) {
					response.sendRedirect(context);
					break;
				}

				final String product = request.getParameter("productId");
				int productId;
				
				try {
					productId = Integer.parseInt(product);
				} catch (NumberFormatException e) {
					formErrorResponse(response, "Неверно указан номер товара: " + (null == product ? "пусто" : product));
					break;
				}
				
				if (Shop.deleteProduct(productId)) {
					success = true;
					formResponse(response, productId);
				}
				else
					formErrorResponse(response, "Удаление товара " + product + " не удалось.");
				
				break;
			}
		}
		
		final StringBuilder buffer = new StringBuilder();
		@SuppressWarnings("unchecked")
		final Map<String, String[]> params = request.getParameterMap();

		for (String name : params.keySet()) {
			buffer.append(name + "=");
			String[] values = params.get(name);

			for (String value : values) {
				buffer.append(value + ";");
			}

			buffer.append("// ");
		}
		
		log("Удаление товара " + (success ? "выполнено" : "не удалось") + "; сессия " + sessionId + "; " + buffer);
	}

	private void formErrorResponse(HttpServletResponse response, String message) throws IOException {
		response.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=utf-8");
		final PrintWriter writer = response.getWriter();
		writer.print("<html><head><title>Удаление товара</title></head><body>");
		writer.print("<h1>" + message + "</h1>");
		writer.println("</body></html>");
	}

	private void formResponse(HttpServletResponse response, int productId) throws IOException {
		final PrintWriter writer = response.getWriter();
		 writer.print("<html><head><title>Удаление товара</title></head><body>");
		 writer.print("<h1>Товар " + productId + "удалён!</h1>");
		 writer.println("</body></html>");
	}

}
