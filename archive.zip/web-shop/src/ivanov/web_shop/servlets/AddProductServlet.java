/**
 * 
 */
package ivanov.web_shop.servlets;

import ivanov.web_shop.controller.Session;
import ivanov.web_shop.controller.Sessions;
import ivanov.web_shop.controller.Shop;
import ivanov.web_shop.domain.Product;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @author papa
 * 
 */
public class AddProductServlet extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4527917126767524491L;

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * javax.servlet.http.HttpServlet#doPost(javax.servlet.http.HttpServletRequest
	 * , javax.servlet.http.HttpServletResponse)
	 */
	@Override
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		final String context = request.getContextPath();
		boolean success = false;
		long sessionId = 0;
		final Cookie[] cookies = request.getCookies();

		if (null == cookies) {
			response.sendRedirect(context);
			log("Добавление товара не выполнено; сессия не задана");
			return;
		}

		for (Cookie cookie : cookies) {

			if (cookie.getName().equals("WebShopSession")) {

				try {
					sessionId = Long.parseLong(cookie.getValue());
				} catch (NumberFormatException e) {
					response.sendRedirect(context);
					break;
				}

				final Session session = Sessions.getSession(sessionId);

				if (null == session) {
					response.sendRedirect(context);
					break;
				}

				if (!session.isAdmin()) {
					response.sendRedirect(context);
					break;
				}

				String name = request.getParameter("name");

				if ((null == name) || (name.length() == 0)) {
					formErrorResponse(response, "Задайте наименование товара.");
					break;
				}

				String description = request.getParameter("description");

				if (null == description) {
					formErrorResponse(response, "Задайте описание товара.");
					break;
				}

				final String sPrice = request.getParameter("price");
				double price;

				try {
					price = Double.parseDouble(sPrice);
				} catch (NumberFormatException e) {
					formErrorResponse(response, "Неверно указана цена товара: " + (null == sPrice ? "пусто" : sPrice));
					break;
				}

				final String sValue = request.getParameter("value");
				double value;

				try {
					value = Double.parseDouble(sValue);
				} catch (NumberFormatException e) {
					formErrorResponse(response, "Неверно указано количество товара: " + (null == sValue ? "пусто" : sValue));
					break;
				}

				Product product = Shop.newProduct(name, description, price,
						value);
				if (null != product) {
					success = true;
					formResponse(response, product);
				} else
					formErrorResponse(response, "Добавление товара " + name + " (" + description + ") не удалось.");
			}
		}

		final StringBuilder buffer = new StringBuilder();
		@SuppressWarnings("unchecked")
		final Map<String, String[]> params = request.getParameterMap();

		for (String name : params.keySet()) {
			buffer.append(name + "=");
			String[] values = params.get(name);

			for (String value : values) {
				buffer.append(value + ";");
			}

			buffer.append("// ");
		}
		
		log("Добавление товара " + (success ? "выполнено" : "не удалось")
				+ "; сессия " + sessionId + "; " + buffer);

	}

	private void formErrorResponse(HttpServletResponse response, String message) throws IOException {
		response.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=utf-8");
		final PrintWriter writer = response.getWriter();
		writer.print("<html><head><title>Добавление товара</title></head><body>");
		writer.print("<h1>" + message + "</h1>");
		writer.println("</body></html>");
	}

	private void formResponse(HttpServletResponse response, Product product)
			throws IOException {
		response.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=utf-8");
		final PrintWriter writer = response.getWriter();
		writer.print("<html><head><title>Добавление товара</title></head><body>");
		writer.print("<h1>Товар добавлен!</h1><table border=1>");

		writer.print("<tr><td>каталожный номер</td><td>" + product.getId()
				+ "</td></tr>");
		writer.print("<tr><td>наименование</td><td>" + product.getName()
				+ "</td></tr>");
		writer.print("<tr><td>описание</td><td>" + product.getDescription()
				+ "</td></tr>");
		writer.print("<tr><td>цена</td><td>" + product.getPrice()
				+ "</td></tr>");
		writer.print("<tr><td>количество</td><td>" + product.getValue()
				+ "</td></tr>");

		writer.println("</table></body></html>");
	}
}
