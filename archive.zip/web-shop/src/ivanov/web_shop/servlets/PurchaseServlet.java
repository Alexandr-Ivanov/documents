/**
 * 
 */
package ivanov.web_shop.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Map;

import ivanov.web_shop.controller.Session;
import ivanov.web_shop.controller.Sessions;
import ivanov.web_shop.controller.Shop;
import ivanov.web_shop.controller.Users;
import ivanov.web_shop.domain.Product;
import ivanov.web_shop.domain.User;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @author papa
 * 
 */
public class PurchaseServlet extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3429239937945825175L;

	@Override
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws IOException {
		request.setCharacterEncoding("UTF-8");
		final String context = request.getContextPath();
		boolean success = false;
		long sessionId = 0;
		final Cookie[] cookies = request.getCookies();

		if (null == cookies) {
			response.sendRedirect(context);
			log("Покупка не выполнена; сессия не задана");
			return;
		}
		
		for (Cookie cookie : cookies) {

			if (cookie.getName().equals("WebShopSession")) {
				
				try {
					sessionId = Long.parseLong(cookie.getValue());
				} catch (NumberFormatException e) {
					response.sendRedirect(context);
					break;
				}
				
				final Session session = Sessions.getSession(sessionId);

				if (null == session) {
					response.sendRedirect(context);
					break;
				}

				if (session.isAdmin()) {
					response.sendRedirect(context);
					break;
				}

				final String product = request.getParameter("product");
				int productId;
				
				try {
					productId = Integer.parseInt(product);
				} catch (NumberFormatException e) {
					formErrorResponse(response, "Неверно указан товар: " + (null == product ? "пусто" : product));
					break;
				}
				
				final String valueString = request.getParameter("value");
				double value;
				try {
					value = Double.parseDouble(valueString);
				} catch (NumberFormatException e) {
					formErrorResponse(response, "Неверно указано количество: " + (null == valueString ? "пусто" : valueString));
					break;
				}

				if (Shop.newPurchase(session.getUserId(), productId, value)) {
					success = true;
					formResponse(response, session, productId, value);
				}
				else
					formErrorResponse(response, "Покупка " + valueString + " товара " + product + " не удалась.");
			}
		}
		
		final StringBuilder buffer = new StringBuilder();
		@SuppressWarnings("unchecked")
		final Map<String, String[]> params = request.getParameterMap();

		for (String name : params.keySet()) {
			buffer.append(name + "=");
			String[] values = params.get(name);

			for (String value : values) {
				buffer.append(value + ";");
			}

			buffer.append("// ");
		}
		
		log("Покупка  " + (success ? "выполнена" : "не удалась") + "; сессия " + sessionId + "; " + buffer);
	}

	private void formErrorResponse(HttpServletResponse response, String message) throws IOException {
		response.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=utf-8");
		final PrintWriter writer = response.getWriter();
		writer.print("<html><head><title>Покупка</title></head><body>");
		writer.print("<h1>" + message + "</h1>");
		writer.println("</body></html>");
	}

	private void formResponse(HttpServletResponse response, Session session, int productId, double value) throws IOException {
		response.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=utf-8");
		final PrintWriter writer = response.getWriter();
		writer.print("<html><head><title>Покупка</title></head><body><h1>Покупка выполнена</h1><table border = 1>");
		 final User user = Users.getUser(session.getUserId());
		 final Product product = Shop.getProduct(productId);
		 
		 writer.print("<tr><td>пользователь</td><td>" + user.getName() + "</td></tr>");
		 writer.print("<tr><td>товар</td><td>" + product.getName() + "</td></tr>");
		 writer.print("<tr><td>цена</td><td>" + product.getPrice() + "</td></tr>");
		 writer.print("<tr><td>количество</td><td>" + value + "</td></tr>");
		 
		 writer.println("</table></body></html>");
	}
}
