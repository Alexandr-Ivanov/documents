/**
 * 
 */
package ivanov.web_shop.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Map;

import ivanov.web_shop.controller.Session;
import ivanov.web_shop.controller.Sessions;
import ivanov.web_shop.controller.Users;
import ivanov.web_shop.domain.User;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @author papa
 *
 */
public class LoginServlet extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 804270154800089549L;
	
	@Override
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
		request.setCharacterEncoding("UTF-8");
		final StringBuilder buffer = new StringBuilder();
		@SuppressWarnings("unchecked")
		final Map<String, String[]> params = request.getParameterMap();
		
		for (String name : params.keySet()) {
			buffer.append(name + "=");
			String[] values = params.get(name);
			
			for (String value : values) {
				buffer.append(value + ";");
			}
			
			buffer.append("// ");
		}
		
		final String userName = request.getParameter("user");
		final String password = request.getParameter("password");
		
		final User user = Users.getUser(userName, password);
		
		if (null == user) {
			response.sendError(HttpServletResponse.SC_NOT_FOUND);
			log("Авторизация пользователя не удалась" + "; " + buffer);
			return;
		}
		
		final Session session = Sessions.newSession(user.getId(), user.isAdmin());
		final Cookie cookie = new Cookie("WebShopSession", String.valueOf(session.getId()));
		
		response.addCookie(cookie);
		//response.setStatus(HttpServletResponse.SC_OK);
		
		if (user.isAdmin())
			formAdminResponse(response, userName);
		else
			formUserResponse(response, userName);
		
		log("Авторизация пользователя выполнена; сессия " + session.getId() + "; " + buffer);
	}

	private void formAdminResponse(HttpServletResponse response, String userName) throws IOException {
		response.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=utf-8");
		final PrintWriter writer = response.getWriter();
		writer.print("<html><head><title>Администратор</title></head><body>");
		writer.print("<h1>Администратор " + userName + ".</h1>");
		writer.print("<a href='adminMenu.html'>нажмите здесь, для продолжения работы</a>");
		writer.println("</body></html>");
	}

	private void formUserResponse(HttpServletResponse response, String userName) throws IOException {
		response.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=utf-8");
		final PrintWriter writer = response.getWriter();
		writer.print("<html><head><title>Пользователь</title></head><body>");
		writer.print("<h1>Пользователь " + userName + ".</h1>");
		writer.print("<a href='userMenu.html'>нажмите здесь, для продолжения работы</a>");
		writer.println("</body></html>");
	}
}
