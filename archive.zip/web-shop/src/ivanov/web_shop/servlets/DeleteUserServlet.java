/**
 * 
 */
package ivanov.web_shop.servlets;

import ivanov.web_shop.controller.Session;
import ivanov.web_shop.controller.Sessions;
import ivanov.web_shop.controller.Shop;
import ivanov.web_shop.controller.Users;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Map;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @author papa
 * 
 */
public class DeleteUserServlet extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8899893470638916465L;

	@Override
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws IOException {
		final String context = request.getContextPath();
		boolean success = false;
		long sessionId = 0;
		final Cookie[] cookies = request.getCookies();

		if (null == cookies) {
			response.sendRedirect(context);
			log("Удаление пользователя не выполнено; сессия не задана");
			return;
		}

		for (Cookie cookie : cookies) {

			if (cookie.getName().equals("WebShopSession")) {

				try {
					sessionId = Long.parseLong(cookie.getValue());
				} catch (NumberFormatException e) {
					response.sendRedirect(context);
					break;
				}

				final Session session = Sessions.getSession(sessionId);

				if (null == session) {
					response.sendRedirect(context);
					break;
				}

				if (!session.isAdmin()) {
					response.sendRedirect(context);
					break;
				}

				final String user = request.getParameter("userId");
				final int userId;

				try {
					userId = Integer.parseInt(user);
				} catch (NumberFormatException e) {
					formErrorResponse(response,
							"Неверно указан номер пользователя: "
									+ (null == user ? "пусто" : user));
					break;
				}

				try {
					final String userName = Users.getUser(userId).getName();
					
					if (Shop.deleteUser(userId)) {
						success = true;
						formResponse(response, userName);
					} else
						formErrorResponse(response, "Удаление пользователя "
								+ user + " не удалось.");
				} catch (Exception e) {
					formErrorResponse(response,
							"Неверно указан номер пользователя: "
									+ (null == user ? "пусто" : user));
					break;
				}
			}
		}

		final StringBuilder buffer = new StringBuilder();
		@SuppressWarnings("unchecked")
		final Map<String, String[]> params = request.getParameterMap();

		for (String name : params.keySet()) {
			buffer.append(name + "=");
			String[] values = params.get(name);

			for (String value : values) {
				buffer.append(value + ";");
			}

			buffer.append("// ");
		}

		log("Удаление пользователя " + (success ? "выполнено" : "не удалось")
				+ "; сессия " + sessionId + "; " + buffer);
	}

	private void formErrorResponse(HttpServletResponse response, String message)
			throws IOException {
		response.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=utf-8");
		final PrintWriter writer = response.getWriter();
		writer.print("<html><head><title>Удаление пользователя</title></head><body>");
		writer.print("<h1>" + message + "</h1>");
		writer.println("</body></html>");
	}

	private void formResponse(HttpServletResponse response, String user)
			throws IOException {
		response.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=utf-8");
		final PrintWriter writer = response.getWriter();
		writer.print("<html><head><title>Удаление пользователя</title></head><body>");
		writer.print("<h1>Пользователь " + user + "удалён!</h1>");
		writer.println("</body></html>");
	}
}