/**
 * 
 */
package ivanov.web_shop.controller;

import java.util.Date;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

/**
 * @author papa
 * 
 */
public class Sessions {
	private static final Sessions sessions = new Sessions();
	private Map<Long, Session> sessionsMap = new ConcurrentHashMap<Long, Session>();
	private AtomicLong counter = new AtomicLong();

	/**
	 * 
	 */
	private Sessions() {
	}

	public static Session newSession(int userId, boolean isAdmin) {
		return newSession(userId, isAdmin, new Date());
	}

	public static Session newSession(int userId, boolean isAdmin, Date beginDate) {
		deleteSessionByUserId(userId);	
		final Session result = new Session((sessions.counter.incrementAndGet() << 32 + userId),
				userId, isAdmin, beginDate);
		sessions.sessionsMap.put(result.getId(), result);
		return result;
	}

	public static boolean validSession(long sessionId) {
		return sessions.sessionsMap.containsKey(sessionId);
	}

	public static Session getSession(long sessionId) {
		return sessions.sessionsMap.get(sessionId);
	}

	public static void deleteSessionByUserId(int userId) {
		
		for (Session session : sessions.sessionsMap.values()) {

			if (session.getUserId() == userId) {
				sessions.sessionsMap.remove(session.getId());
				break;
			}
		}
	}
}
