/**
 * 
 */
package ivanov.web_shop.controller;

import java.util.Collection;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import ivanov.web_shop.Globals;
import ivanov.web_shop.domain.Product;
import ivanov.web_shop.domain.Purchase;
import ivanov.web_shop.domain.User;

/**
 * @author papa
 * 
 */
public class Shop {
	private static final Shop shop = new Shop();
	private final ConcurrentMap<Integer, Product> products = new ConcurrentHashMap<Integer, Product>();

	/**
	 * 
	 */
	private Shop() {
		final EntityManager em = Globals.emf.createEntityManager();
		final EntityTransaction tx = em.getTransaction();
        tx.begin();
        final CriteriaQuery<Product> criteriaQuery = em.getCriteriaBuilder().createQuery(Product.class);
        final Root<Product> root = criteriaQuery.from(Product.class);
        criteriaQuery.select(root);
		final List<Product> result = em.createQuery(criteriaQuery).getResultList();
        
        for (Product product : result) {
        	products.put(product.getId(), product);
        }
        
        tx.commit();
        em.close();
	}

	public static boolean newPurchase(int userId, int productId, double value) {
		final User user = Users.getUser(userId);
		
		if (null == user)
			return false;
		
		final Product product = shop.products.get(productId);

		if (null == product)
			return false;
		
		if (value <= 0)
			return false;

		synchronized (product) {
			if (product.getValue() < value)
				return false;

			final Purchase purchase = new Purchase(userId, productId, product.getPrice(), value);
			product.subtract(value);
			final EntityManager em = Globals.emf.createEntityManager();
	        final EntityTransaction tx = em.getTransaction();
	        tx.begin();
	        em.persist(purchase);
	        em.merge(product);
	        tx.commit();
	        em.close();
		}

		return true;
	}
	
	public static Collection<Product> getProducts() {
		return shop.products.values();
	}
	
	public static Product newProduct(String name, String description, double price, double value) {
		for (Product product : shop.products.values()) {
			
			if (product.getName() == name)
				return null;
		}
		
		final Product newProduct = new Product(name, description, price, value);
		final EntityManager em = Globals.emf.createEntityManager();
        final EntityTransaction tx = em.getTransaction();
        tx.begin();
        em.persist(newProduct);
        tx.commit();
        em.close();
        shop.products.put(newProduct.getId(), newProduct);
		return newProduct;
	}
	
	public static boolean changeProduct(int productId, String name, String description, double price, double value) {
		final Product product = shop.products.get(productId);
		
		if (null == product)
			return false;
		
		synchronized(product) {
			product.setName(name);
			product.setDescription(description);
			product.setPrice(price);
			product.setValue(value);
			final EntityManager em = Globals.emf.createEntityManager();
	        final EntityTransaction tx = em.getTransaction();
	        tx.begin();
	        em.merge(product);
	        tx.commit();
	        em.close();
	        return true;
		}
	}
	
	public static boolean deleteProduct(int productId) {
		final Product product = shop.products.get(productId);
		
		if (null == product)
			return false;
		
		synchronized(product) {
			final EntityManager em = Globals.emf.createEntityManager();
	        final EntityTransaction tx = em.getTransaction();
	        tx.begin();
	        em.remove(em.merge(product));
	        tx.commit();
	        em.close();
	        shop.products.remove(product);
	        return true;
		}
	}

	public static Product getProduct(int productId) {
		return shop.products.get(productId);
	}

	public static boolean deleteUser(int userId) {
		Sessions.deleteSessionByUserId(userId);
		return Users.deleteUser(userId);
	}

	public static Collection<Purchase> getPurchases() {
		final EntityManager em = Globals.emf.createEntityManager();
		final EntityTransaction tx = em.getTransaction();
        tx.begin();
        final CriteriaQuery<Purchase> criteriaQuery = em.getCriteriaBuilder().createQuery(Purchase.class);
        final Root<Purchase> root = criteriaQuery.from(Purchase.class);
        criteriaQuery.select(root);
		final List<Purchase> result = em.createQuery(criteriaQuery).getResultList();
        tx.commit();
        em.close();
        return result;
	}
}
