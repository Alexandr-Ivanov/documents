package ivanov.web_shop.controller;

import java.util.Date;

public class Session {
	private final long id;
	private final int userId;
	private final boolean isAdmin;
	private final Date beginTime;
	
	Session(long anId, int anUserId, boolean anIsAdmin, Date aBeginTime){
		id = anId;
		userId = anUserId;
		isAdmin = anIsAdmin;
		beginTime = aBeginTime;
	}
	/**
	 * @return the id
	 */
	public long getId() {
		return id;
	}
	/**
	 * @return the userId
	 */
	public int getUserId() {
		return userId;
	}
	/**
	 * @return the isAdmin
	 */
	public boolean isAdmin() {
		return isAdmin;
	}
	/**
	 * @return the beginTime
	 */
	public Date getBeginTime() {
		return beginTime;
	}
	@Override
	public int hashCode() {
		return (int) id;
	}
	@Override
	public boolean equals(Object o) {
		if(this == o)
			return true;
		
		if(!(o instanceof Session))
			return false;
		
		return this.id == ((Session) o).id;
	}
}