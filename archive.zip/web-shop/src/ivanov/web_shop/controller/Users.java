/**
 * 
 */
package ivanov.web_shop.controller;

import ivanov.web_shop.Globals;
import ivanov.web_shop.domain.User;

import java.util.Collection;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

/**
 * @author papa
 *
 */
public class Users {
	private static final Users users = new Users();
	private final ConcurrentMap<String, User> usersMap = new ConcurrentHashMap<String, User>();
	
	/**
	 * 
	 */
	private Users() {
		final EntityManager em = Globals.emf.createEntityManager();
		final EntityTransaction tx = em.getTransaction();
        tx.begin();
        final CriteriaQuery<User> criteriaQuery = em.getCriteriaBuilder().createQuery(User.class);
        final Root<User> root = criteriaQuery.from(User.class);
        criteriaQuery.select(root);
		final List<User> result = em.createQuery(criteriaQuery).getResultList();
        
        for (User user : result) {
        	usersMap.put(user.getName(), user);
        }
        
        tx.commit();
        em.close();
	}

	public static User getUser(String userName, String password) {
		final User user = users.usersMap.get(userName);
		
		if (null == user)
			return null;
		
		return user.getPassword().equals(password) ? user: null;
	}
	
	public static boolean addUser(String userName, String password) {
		User user = users.usersMap.get(userName);
		
		if (null != user)
			return false;
		
		user = new User(userName, password);
		
		if (null == users.usersMap.putIfAbsent(userName, user)) {
			final EntityManager em = Globals.emf.createEntityManager();
	        final EntityTransaction tx = em.getTransaction();
	        tx.begin();
	        em.persist(user);
	        tx.commit();
	        em.close();
			return true;
		}
		else 			
			return false;
	}

	public static User getUser(int userId) {
		for (User user : users.usersMap.values()) {
		
			if (user.getId() == userId)
				return user;
		}
		
		return null;
	}
	
	public static Collection<User> getUsers() {
		return users.usersMap.values();
	}
	
	public static boolean deleteUser(int userId) {
		final User user = getUser(userId);
		
		if (null == user)
			return false;
		
		if (users.usersMap.remove(user.getName(), user)) {
			final EntityManager em = Globals.emf.createEntityManager();
	        final EntityTransaction tx = em.getTransaction();
	        tx.begin();
	        em.remove(em.merge(user));
	        tx.commit();
	        em.close();
			return true;
		}
		else 			
			return false;
	}
}
