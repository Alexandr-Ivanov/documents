package ivanov.web_shop;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

/**
 * @author papa
 *
 */
public class HibernateListener implements ServletContextListener {

	/**
	 * 
	 */
	public HibernateListener() {
	}

	/* (non-Javadoc)
	 * @see javax.servlet.ServletContextListener#contextDestroyed(javax.servlet.ServletContextEvent)
	 */
	@Override
	public void contextDestroyed(ServletContextEvent event) {
		getEntityManagerFactory().close();

	}

	/* (non-Javadoc)
	 * @see javax.servlet.ServletContextListener#contextInitialized(javax.servlet.ServletContextEvent)
	 */
	@Override
	public void contextInitialized(ServletContextEvent event) {
		ServletContext context = event.getServletContext();        
		setEntityManagerFactory(Persistence.createEntityManagerFactory("web_shop"));
		context.setAttribute("emf", getEntityManagerFactory());

	}

	/**
	 * @return the entityManagerFactory
	 */
	public static EntityManagerFactory getEntityManagerFactory() {
		return Globals.emf;
	}

	/**
	 * @param entityManagerFactory the entityManagerFactory to set
	 */
	public static void setEntityManagerFactory(EntityManagerFactory entityManagerFactory) {
		Globals.emf = entityManagerFactory;
	}

}
